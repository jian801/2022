﻿    Crass means a tool chain for game resources. It consists of two parts: Crage, which extracts game resources from archives, and/or converts proprietary formats into standard formats, via "cui" plugin extensions; and Assage, which packs files back into archives, via "aui" plugin extensions.
 
    With the right "cui" and "aui" plugins, game resources can be unpacked from/packed into supported archive formats.

    For ordinary users, CrageGUI gives access to Crage through a graphical user interface; for advanced users, Crage also provides a command line interface for finer control. Further usage instructions of Crage can be found in INSTALL.TXT; details of each "cui" plugin can be found in the documents folder, please read them before using Crage.

    Development of Assage and the "aui" plugins is postponed until Crage's framework stablizes; neither will the SDK be open for release before that.

	the newest version:
		http://galcrass.blog124.fc2.com/

	cui update:
		http://galcrass.blog124.fc2.com/blog-entry-1.html

	partial cui source code(ver 1.0.4):
		http://www.aishare.net/link.php?ref=tYsE9l9Nyu

	quiz and bug report:
		https://www.yukict.com/bbs/thread-13010-1-1.html

	pcicp's CG rip blog:
		http://haibarascgrip.baywords.com/
